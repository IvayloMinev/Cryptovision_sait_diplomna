function nav(btn, name) {
  document.querySelectorAll('.sec').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('#mainNav button').forEach(b => b.classList.remove('active'));
  document.getElementById('sec-' + name).classList.add('active');
  btn.classList.add('active');

  if (name === 'charts' && allCoins.length && !document.getElementById('coinSel').value) {
    document.getElementById('coinSel').value = 'bitcoin';
    loadChart();
  }
  if (name === 'portfolio') renderPortfolio();
  if (name === 'news' && !newsLoaded) loadNews();
}

document.addEventListener('DOMContentLoaded', () => {
  loadMarket();
  loadNews();
  setInterval(loadMarket, 60_000);
});
