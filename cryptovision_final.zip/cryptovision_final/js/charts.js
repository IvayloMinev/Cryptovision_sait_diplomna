let chartInst = null;
let chartTF   = '7';

const TF_CONFIG = {
  '1':   { label: '1Д',  unit: 'hour' },
  '7':   { label: '7Д',  unit: 'hour' },
  '30':  { label: '1М',  unit: 'day'  },
  '365': { label: '1Г',  unit: 'day'  },
};

function gotoChart(coinId) {
  document.querySelectorAll('#mainNav button').forEach((b, i) => b.classList.toggle('active', i === 1));
  document.querySelectorAll('.sec').forEach(s => s.classList.remove('active'));
  document.getElementById('sec-charts').classList.add('active');
  document.getElementById('coinSel').value = coinId;
  loadChart();
}

function setTF(btn, tf) {
  document.querySelectorAll('.tf-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  chartTF = tf;
  loadChart();
}

async function loadChart() {
  const coinId = document.getElementById('coinSel').value;
  if (!coinId) return;

  const wrap = document.getElementById('priceChart').parentElement;
  wrap.innerHTML = '<div class="loading"><div class="spin"></div> Зареждане…</div>';

  try {
    const res = await fetch(
      `https://api.coingecko.com/api/v3/coins/${coinId}/ohlc?vs_currency=usd&days=${chartTF}`
    );
    if (!res.ok) throw new Error('CoinGecko error');
    const raw = await res.json();

    const candles = raw.map(([t, o, h, l, c]) => ({ x: t, o, h, l, c }));

    wrap.innerHTML = '<canvas id="priceChart"></canvas>';
    const ctx = document.getElementById('priceChart').getContext('2d');

    if (chartInst) chartInst.destroy();

    chartInst = new Chart(ctx, {
      type: 'candlestick',
      data: {
        datasets: [{
          label: coinId,
          data: candles,
          color:       { up: '#00ff88', down: '#ff3d71', unchanged: '#4a6080' },
          borderColor: { up: '#00ff88', down: '#ff3d71', unchanged: '#4a6080' }
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#0c1118',
            borderColor: '#1a2840',
            borderWidth: 1,
            titleColor: '#4a6080',
            bodyColor: '#e2e8f0',
            callbacks: {
              label: ctx => {
                const d = ctx.raw;
                return [`O: ${fPrice(d.o)}`, `H: ${fPrice(d.h)}`, `L: ${fPrice(d.l)}`, `C: ${fPrice(d.c)}`];
              }
            }
          }
        },
        scales: {
          x: {
            type: 'timeseries',
            time: {
              unit: TF_CONFIG[chartTF].unit,
              displayFormats: { hour: 'dd MMM HH:mm', day: 'dd MMM' }
            },
            grid:  { color: 'rgba(255,255,255,.03)' },
            ticks: { color: '#4a6080', font: { family: 'JetBrains Mono', size: 11 }, maxTicksLimit: 10 }
          },
          y: {
            position: 'right',
            grid:  { color: 'rgba(255,255,255,.03)' },
            ticks: { color: '#4a6080', font: { family: 'JetBrains Mono', size: 11 }, callback: v => fPrice(v) }
          }
        }
      }
    });

    const closes = candles.map(c => c.c);
    const cur    = closes[closes.length - 1];
    const chg    = ((cur - closes[0]) / closes[0]) * 100;
    const high   = Math.max(...candles.map(c => c.h));
    const low    = Math.min(...candles.map(c => c.l));

    document.getElementById('csPrice').textContent = fPrice(cur);
    document.getElementById('csPrice').className   = 'val ' + pClass(chg);
    document.getElementById('csChg').textContent   = fPct(chg);
    document.getElementById('csChg').className     = 'val ' + pClass(chg);
    document.getElementById('csHigh').textContent  = fPrice(high);
    document.getElementById('csLow').textContent   = fPrice(low);

  } catch (err) {
    wrap.innerHTML = '<div class="loading">⚠️ Грешка при зареждане на графиката.</div>';
  }
}
